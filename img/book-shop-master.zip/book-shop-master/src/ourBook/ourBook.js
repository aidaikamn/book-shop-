import React from 'react';
import Books from "../components/books/Books";
import Header from "../components/header/Header";
import Footer from "../components/footer/Footer";

const OurBook = () => {
    return (
        <div>
            <Books/>
        </div>
    );
};

export default OurBook;