import React from 'react';


const MainPage = () => {
    return (
      <div>

      </div>

    );
};

export default MainPage;