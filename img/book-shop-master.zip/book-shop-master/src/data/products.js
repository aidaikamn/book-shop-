import IMG1 from "../img/genres1.svg"
import IMG2 from "../img/img8.svg"

export const products = [
    [
        {
            id:1,
            title:"Genres",
            view:"view all",
            img:IMG1
        },

        {

            img:IMG2
        },
        {
            img:IMG2
        }
    ]
]